<?php

/* * *************************************************************************************
 *                       		group_model.php
 * **************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	group_model
 *      Created:   	26 Jan 14 10:23:29 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 			Version 1, December 2009
 * 			Copyright (C) 2009 Philip Sturgeon
 *
 * ************************************************************************************** */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Group_Model extends CI_Model{
    //put your code here
    function __construct()
    {
        parent::__construct();
    }
    
    function addGroup()
    {
        
    }
    
    function deleteGroup()
    {
        
    }
}

/* End of File: group_model.php */