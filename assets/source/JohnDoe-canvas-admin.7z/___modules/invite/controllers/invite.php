<?php

/***************************************************************************************
 *                       		invite.php
 ***************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	notifikasi
 *      Created:   	25 Jan 14 12:54:00 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 			Version 1, December 2009
 *			Copyright (C) 2009 Philip Sturgeon
 *
 ****************************************************************************************/

class Invite extends Front_Controller
{
    function __construct()
    {
        parent::__construct();
    }
    
    function index()
    {
        echo "Okeh notif nya";
    }
}
/* End of File: invite.php */
