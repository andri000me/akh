<?php

/* * *************************************************************************************
 *                       		member.php
 * **************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	member
 *      Created:   	26 Jan 14 0:20:27 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 			Version 1, December 2009
 * 			Copyright (C) 2009 Philip Sturgeon
 *
 * ************************************************************************************** */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class member extends Front_Controller {
    //put your code here
    function __construct()
    {
        parent::__construct();
    }
}

/* End of File: member.php */