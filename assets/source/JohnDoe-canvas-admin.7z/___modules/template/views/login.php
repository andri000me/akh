<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
    <head>

        <title>Aplikasi Kegiatan Harian - Login</title>

        <meta charset="utf-8" />
        <meta name="description" content="" />
        <meta name="author" content="" />		
        <meta name="viewport" content="width=device-width,initial-scale=1" />
        <?=css('reset.css');?>
        <?=css('text.css');?>
        <?=css('buttons.css');?>
        <?=css('theme-default.css');?>
        <?=css('login.css');?>
        <?=css('flags.css');?>
        
    </head>

    <body>
        <?php
        $this->load->view($module . '/' . $view);
        ?>
        
        <!-- Default Canvas JS -->
        <?=js('all.js');?>
    </body>
</html>