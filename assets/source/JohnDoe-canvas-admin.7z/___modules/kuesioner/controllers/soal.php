<?php

/* * *************************************************************************************
 *                       		soal.php
 * **************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	soal
 *      Created:   	13:21:53 27 Jan 14
 *      Copyright:  	(c) 2014 - JohnDoe
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 			Version 1, December 2009
 * 			Copyright (C) 2009 Philip Sturgeon
 *
 * ************************************************************************************** */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Soal extends Front_Controller {
    //put your code here
    function __construct() {
        parent::__construct();
        
        $this->load->model('kuesioner/soal_model');
    }
    
    function index()
    {
        $this->_manage();
    }
    
    function _manage() 
    {
        // TODO: Vagination..
        
        $data['soals'] = $this->soal_model->findSoalAll();

        $data['kuesioner'] = "soal"; // Controller
        $data['view'] = "index_soal"; // View
        $data['module'] = "kuesioner"; // Controller

        echo Modules::run('template/admin', $data);
    }
    
    function add()
    {
        $this->load->view('form_soal');
    }
    
    function proses() 
    {
       
    }
    
    function edit()
    {
        
    }
    
    function delete()
    {
        $data = $_REQUEST;
        $this->soal_model->deleteSoal($data);

        $output['success'] = 1;
        $output['msg'] = "delete successfully records";

        echo json_encode($output);
    }
}

/* End of File: soal.php */