<?php
class Welcome extends MX_Controller
{
    function __construct() {
        parent::__construct();
    }
    
    function index()
    {
        echo "Welcome to module section";
    }
}
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
