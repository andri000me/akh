<?php

/* * *************************************************************************************
 *                       		translate.php
 * **************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	translate
 *      Created:   	16:38:56 04 Feb 14
 *      Copyright:  	(c) 2014 - JohnDoe
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 			Version 1, December 2009
 * 			Copyright (C) 2009 Philip Sturgeon
 *      
 *      source:         http://cyberqoe.wordpress.com/2011/03/08/codeigniter-multi-language-part-1/
 *
 * ************************************************************************************** */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

if (!function_exists('trans'))
{
    function trans($kata)
    {        
        $CI = & get_instance();
        $CI->lang->load('cakra');
        $jawaban = $CI->lang->line($kata);
        
        return $jawaban;
    }
}

/* End of File: translate.php */