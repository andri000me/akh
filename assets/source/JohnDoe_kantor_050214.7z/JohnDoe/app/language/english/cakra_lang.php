<?php

$lang['cakra_home'] = "home";