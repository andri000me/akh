<?php

$lang['cakra_home'] = "Beranda";