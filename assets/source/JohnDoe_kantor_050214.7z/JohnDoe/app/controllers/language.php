<?php

class Language extends Front_Controller {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $this->load->view('translate');
    }

    function set_to($language) 
    {
        $folder = 'application/language/';
        $languagefiles = scandir($folder);
        if (in_array($language, $languagefiles)) {
            $cookie = array(
                'name' => 'bahasa',
                'value' => $language,
                'expire' => '31536000',
            );

            $this->input->set_cookie($cookie);
        }
      if ($this->input->server('HTTP_REFERER'))
      redirect($this->input->server('HTTP_REFERER'));
    }

    /*
      function set_to($language)
      {
      if(strtolower($language) == 'english')
      {
      $lang = 'en';
      }
      elseif (strtolower($language) == 'arabic')
      {
      $lang = 'ar';
      }else
      {
      $lang = 'id';
      }

      set_cookie(array(
      'name' => 'bahasa',
      'value' => $lang,
      'expire' => '86500',
      'prefix' => ''));

      if ($this->input->server('HTTP_REFERER'))
      redirect($this->input->server('HTTP_REFERER'));
      }
     */
}
