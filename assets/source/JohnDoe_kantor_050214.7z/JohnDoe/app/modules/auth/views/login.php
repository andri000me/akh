<div id="login">
    <h1>Dashboard</h1>
    <div id="login_panel">
        <?= form_open("auth/login"); ?>
        <div class="login_actions">
            Aplikasi Kegiatan Harian - Login
        </div>
       
            <?php echo $message; ?>
      
        <div class="login_fields">
            <div class="field">
                <label for="identity">Email</label>
                <input type="text" name="identity" value="" id="identity" tabindex="1" placeholder="email@example.com" />		
            </div>

            <div class="field">
                <label for="password">Password <small><a href="javascript:;">Forgot Password?</a></small></label>
                <input type="password" name="password" value="" id="password" tabindex="2" placeholder="password" />			
            </div>
        </div> <!-- .login_fields -->
        <div class="widget-content">
            <div class="login_actions">
                <button type="submit" class="btn btn-primary" tabindex="3"><span class="icon-arrow-curved"></span>Login</button>
                |
                <label for="registrasi"><small><a href="<?=site_url('auth/registrasi')?>">Register</a></small></label>
            </div>
        </div>
        <?= form_close(); ?>
    </div> <!-- #login_panel -->		
</div> <!-- #login -->