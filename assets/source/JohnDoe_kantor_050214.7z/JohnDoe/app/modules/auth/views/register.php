<div id="login">
    <h1>Dashboard</h1>
    <div id="login_panel">
        <?= form_open("auth/registrasi"); ?>
        <div class="login_actions">
         Aplikasi Kegiatan Harian - Login
        </div>
       
            <?php echo $message; ?>
      
        <div class="login_fields">
            <div class="field">
                <label for="identity">Email</label>
                <input type="text" name="identity" value="" id="identity" tabindex="1" placeholder="email@example.com" />		
            </div>
            
            <div class="field">
                <label for="username">Username</label>
                <input type="text" name="username" value="" id="username" tabindex="1" placeholder="Username" />		
            </div>
            
            <div class="field">
                <label for="first_name">Nama Depan</label>
                <input type="text" name="first_name" value="" id="first_name" tabindex="1" placeholder="Nama Depan" />		
            </div>
            
            <div class="field">
                <label for="last_name">Nama Belakang</label>
                <input type="text" name="last_name" value="" id="last_name" tabindex="1" placeholder="Nama Belakang" />		
            </div>
            
            <div class="field">
                <label for="phone">Telepone</label>
                <input type="text" name="phone" value="" id="phone" tabindex="1" placeholder="phone" />		
            </div>
            
            <div class="field">
                <label for="company">Divisi</label>
                <input type="text" name="company" value="" id="company" tabindex="1" placeholder="Divisi" />		
            </div>

            <div class="field">
                <label for="password">Password</label>
                <input type="password" name="password" value="" id="password" tabindex="2" placeholder="password" />			
            </div>
            
            <div class="field">
                <label for="password_confirm">Konfirmasi Password</label>
                <input type="password_confirm" name="password_confirm" value="" id="password_confirm" tabindex="2" placeholder="Konfirmasi Password" />			
            </div>
            
        </div> <!-- .login_fields -->
        <div class="widget-content">
            <div class="login_actions">
                <button type="submit" class="btn btn-primary" tabindex="3"><span class="icon-arrow-curved"></span>Daftar</button>
                |
                <label for="login"><small><a href="<?=site_url('auth/login')?>">Login</a></small></label>
            </div>
        </div>
        <?= form_close(); ?>
    </div> <!-- #login_panel -->		
</div> <!-- #login -->