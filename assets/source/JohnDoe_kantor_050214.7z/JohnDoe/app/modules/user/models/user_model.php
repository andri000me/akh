<?php

/* * *************************************************************************************
 *                       		user_model.php
 * **************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	user_model
 *      Created:   	26 Jan 14 7:21:45 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 			Version 1, December 2009
 * 			Copyright (C) 2009 Philip Sturgeon
 *
 * ************************************************************************************** */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class user_model extends CI_Model{
    //put your code here
    
    function addUser($data)
    {
        $this->db->set('first_name', $data['first_name']);
        $this->db->insert('user');
    }
    
    function deleteUser($data)
    {
        $this->db->delete('user', array('user_id' => $data['user_id']));
    }
}

/* End of File: user_model.php */