<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class User extends Admin_Controller {

    function __construct()
    {
        // Everyting in on place
        parent::__construct();
    }
    
    function debuk()
    {
        $query = $this->db->get('users');
        
        $this->excel_generator->set_query($query);
        $this->excel_generator->set_header(array('username', 'email', 'company', 'first_name'));
        $this->excel_generator->set_column(array('username', 'email', 'company', 'first_name'));
        $this->excel_generator->set_width(array(25, 15, 30, 15));
        $this->excel_generator->exportTo2003('Laporan Users');
    }

    function index()
    {
      if ($this->ion_auth->is_admin())
        {
            //$data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
            $data['message'] = (validation_errors() ? '<div class="alert alert-error"><a class="close" data-dismiss="alert">X</a>' . validation_errors() . '</div>' : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message')));

            // paging
            $this->load->library('pagination');

            $uri_segment = 3;
            $data['offset'] = $this->uri->segment($uri_segment);

            $config['base_url'] = base_url() . 'user/index/';
            $config['total_rows'] = $this->ion_auth->users()->num_rows();
            $config['per_page'] = 18;
            $config['next_link'] = '<li>Selanjutnya</li>';
            $config['prev_link'] = '<li>Sebelumnya</li>';
            $config['cur_tag_open'] = '<li class="active"><a href="#">..</a> - Halaman ke ';
            $config['cur_tag_close'] = ' </li>';

            // I don't know how this work! i found it in ellislab.com sharing forum
            $data['users'] = $this->ion_auth->offset(
                                  $this->uri->segment($uri_segment))
                                            ->limit($config['per_page'])
                                            ->order_by('created_on') //active
                                            ->users()
                                            ->result_array();

            // run paging
            $this->pagination->initialize($config);
            $data['paging'] = $this->pagination->create_links();

            // Template
            $data['user'] = "user"; // Controller
            $data['view'] = "index"; // View
            $data['module'] = "user"; // Controller

            echo Modules::run('template/admin', $data);
        }
        else
        {
            redirect('auth', 'refresh');
        }
    }

    function form_pengguna()
    {
        $this->load->view('user/tambah');
    }

    function proses()
    {
        $data = $_REQUEST;

        // this for add new records
        if ($data['type'] == 'addUser')
        {
            $this->ion_auth->register($data);
        }
        // this for update records
        else if ($data['type'] == 'updateUser')
        {
            $this->ion_auth->update($data);
        }

        if ($data['tambahUser'] === "true")
        {

            $output['success'] = 1;
            $output['msg'] = "data process complete successfully";
            echo json_encode($output);
        }
        else
        {
            header("Location: " . base_url() . "index.php/user/");
            exit();
        }
    }

}