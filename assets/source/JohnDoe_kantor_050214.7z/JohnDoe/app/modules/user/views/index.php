<div class="grid-24">

    <div class="widget widget-table">

        <div class="widget-header">
            <span class="icon-list"></span>
            <h3 class="icon chart">

                <div class="widget-content">

                <label for="registrasi"><small><a href="#" id="popupUser">Tambah</a></small></label>

                </div> <!-- .widget-content -->
            </h3>		
        </div>

        <div class="widget-content">

            <table class="table table-bordered table-striped data-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
        <?php $i = 0;?>
	<?php foreach ($users as $user):?>
                <tbody>
                    <tr class="gradeA">
                        <td><?= ++$i;?></td>
                        <td><?= $user['username']?></td>
                        <td><?= $user['email']?></td>
                        <td><?= $user['active'] ? 'Aktif' : 'Tidak Aktif'?></td>
                        <td width ="2" colspan="2">
                            Hhhh |
                            Bgggg |
                            Export
                        </td>
                    </tr>
                </tbody>
	<?php endforeach;?>
            </table>
        </div> <!-- .widget-content -->

    </div> <!-- .widget -->
</div>

<script>
    $(function (){
        $('#popupUser').live('click', function (e){
            e.preventDefault();
            
            $.modal({
                title:  'Tambah Data Pengguna',
                ajax:   'user/form_pengguna'
            });
        });
    });
</script>