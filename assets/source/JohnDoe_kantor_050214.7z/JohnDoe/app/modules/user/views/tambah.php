
<form id="tambahUser" action="<?= base_url('index.php/user/proses/'); ?>" method="post"  name="newproject" enctype="multipart/form-data">
    <table>
        <tr>
            <td>Username</td>
            <td><input class="validate[required]" id="username"  size="32" name="username" type="text" value="" placeholder="email@example.com"/></td>
        </tr>
       
        <tr>
            <td><label for="email">Email</label></td>
            <td><input type="text" name="email" size="32" value="" id="email" tabindex="1" placeholder="email@example.com" /></td>
        </tr>
        <tr>
            <td><label for="first_name">First Name</label></td>
            <td><input type="text" name="first_name" value="" size="32" id="first_name" tabindex="1" placeholder="email@example.com" /></td>
        </tr>
        <tr>
            <td><label for="last_name">Last Name</label></td>
            <td><input type="text" name="last_name" value="" size="32" id="last_name" tabindex="1" placeholder="email@example.com" /></td>
        </tr>
        <tr>
            <td><label for="email">Email</label></td>
            <td><input type="text" name="email" value="" size="32" id="email" tabindex="1" placeholder="email@example.com" /></td>
        </tr>
        <tr>
            <td>
                <button class="btn btn-small" onclick="save()" value="submit">Simpan</button>
            </td>

            <td> | <a href="<?= base_url('index.php/user/'); ?>"> cancel</a></td>
        </tr>
    </table>
</form>

<script>
                    $(document).ready(function() {
                        $("#tambahUser").validationEngine();
                    });

                    function save()
                    {
                        var validate = $('$tambahUser').validateEngine("validate");
                        if (!validate) {
                            return false;
                        }

                        var submit = $('#tambahUser').serialize();
                        $.ajax({
                        });
                    }
</script>