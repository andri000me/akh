<?php

/* * *************************************************************************************
 *                       		group.php
 * **************************************************************************************
 *      Author:     	Topidesta as Shabiki <m.desta.fadilah@hotmail.com>
 *      Website:    	http://www.twitter.com/emang_dasar
 *
 *      File:          	group
 *      Created:   	26 Jan 14 10:22:41 WIB
 *      Copyright:  	(c) 2012 - desta
 *                  	DON'T BE A DICK PUBLIC LICENSE
 * 			Version 1, December 2009
 * 			Copyright (C) 2009 Philip Sturgeon
 *
 * ************************************************************************************** */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class group extends Admin_Controller {

    //put your code here

    function __construct()
    {
        parent::__construct();
    }

    function index()
    {
        
        
        // Template
        $data['group'] = "group"; // Controller
        $data['view'] = "index"; // View
        $data['module'] = "group"; // Controller

        echo Modules::run('template/admin', $data);
    }

    function formGroup()
    {
        $this->load->view('group/tambah');
    }

    function proses()
    {
        
    }

}

/* End of File: group.php */