
<form id="tambahGroup" action="<?= base_url('index.php/group/proses/'); ?>" method="post"  name="newproject" enctype="multipart/form-data">
    <table>
        <tr>
            <td>Level</td>
            <td><input class="validate[required]" id="name"  name="name" type="text" placeholder="Group/ Level"/></td>
        </tr>
        <tr>
            <td>Keterangan</td>
            <td><input type="text" name="description" value="" id="description" tabindex="1" placeholder="Keterangan" /></td>
        </tr>
       
        <tr>
            <td>
                <button class="btn btn-small" onclick="save()" value="submit">Simpan</button>
            </td>

            <td> | <a href="<?= base_url('index.php/group/'); ?>"> cancel</a></td>
        </tr>
    </table>
</form>

<script>
                    $(document).ready(function() {
                        $("#tambahGroup").validationEngine();
                    });

                    function save()
                    {
                        var validate = $('$tambahGroup').validateEngine("validate");
                        if (!validate) {
                            return false;
                        }

                        var submit = $('#tambahGroup').serialize();
                        $.ajax({
                        });
                    }
</script>