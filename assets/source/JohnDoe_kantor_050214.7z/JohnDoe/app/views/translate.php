<a href="<?=base_url()?>language/set_to/indonesia" title="Indonesia">Indonesia</a>
<br />
<a href="<?=base_url()?>language/set_to/english" title="Indonesia">Inggris</a>

<?php echo lang('cakra_home');?> <br />
<?php echo $this->lang->line('cakra_home');?>